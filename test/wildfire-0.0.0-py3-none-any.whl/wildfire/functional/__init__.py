from wildfire.functional.star import star
from wildfire.functional.starcompose import starcompose
from wildfire.functional.structure_map import structure_map
